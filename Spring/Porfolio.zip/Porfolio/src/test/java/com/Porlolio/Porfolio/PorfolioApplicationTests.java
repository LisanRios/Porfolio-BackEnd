package com.Porlolio.Porfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PorfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
