package com.LisandroRios.porfolioweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PorfoliowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
